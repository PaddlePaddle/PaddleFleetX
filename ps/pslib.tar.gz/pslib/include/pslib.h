/* Copyright (c) 2018 PaddlePaddle Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License. */

#pragma once

#include "communicate/ps_server.h"
#include "communicate/ps_client.h"

namespace paddle {
namespace distributed {

    class PSlib {
    public:
        explicit PSlib() {};
        virtual ~PSlib(){};

        virtual int init_server(const std::string& filename, int index);
        virtual int init_worker(const std::string& filename, uint64_t* host_sign_list, int node_num, int index);
        virtual uint64_t run_server();
        virtual int stop_server();
        virtual int gather_servers(uint64_t* host_sign_list, int node_num);
        virtual int gather_clients(uint64_t* host_sign_list, int node_num);
        virtual std::vector<uint64_t> get_client_info();
        virtual int create_client2client_connection();
        std::shared_ptr<paddle::ps::PSServer> _server_ptr;  // pointer to server
        std::shared_ptr<paddle::ps::PSClient> _worker_ptr;  // pointer to worker
        virtual paddle::PSParameter* get_param();
    private:
        void init_gflag() {
            int cnt = 4;
            std::shared_ptr<char*> params(new char*[cnt]);
            char** params_ptr = params.get();
            char p0[] = "exe default";
            char p1[] = "-max_body_size=314217728";
            char p2[] = "-bthread_concurrency=40";
            char p3[] = "-socket_max_unwritten_bytes=2048000000";
            params_ptr[0] = p0;
            params_ptr[1] = p1;
            params_ptr[2] = p2;
            params_ptr[3] = p3;
            ::google::ParseCommandLineFlags(&cnt, &params_ptr, true);
        }
        paddle::PSParameter _ps_param;
        paddle::ps::PaddlePSEnvironment _ps_env;
    };

}  // namespace distributed
}  // namespace paddle
