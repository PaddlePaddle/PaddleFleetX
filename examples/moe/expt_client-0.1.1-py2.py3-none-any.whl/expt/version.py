#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################

"""
init

Authors: yangjintao
Date:    2020/08/26
"""

version = '0.1.1'
