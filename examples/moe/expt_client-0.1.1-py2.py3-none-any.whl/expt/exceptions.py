#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################

"""
init

Authors: yangjintao
Date:    2020/08/24
"""


class ExptException(Exception):
    """
    Expt Exception
    """
    pass


class NoExpNameException(ExptException):
    """
    no exp name exception
    """
    def __init__(self):
        super(NoExpNameException, self).__init__(
            "You must set the experiment name, use expt.init(name=\"Exp_Name\").")


class NoExpTokenException(ExptException):
    """
    no exp token exception
    """
    def __init__(self):
        super(NoExpTokenException, self).__init__(
            "You must set the token, use expt.init(token=\"Exp_Token\"). "
            "You can get token on web page.")


class FormatException(ExptException):
    """
    format exception
    """
    def __init__(self, msg):
        super(FormatException, self).__init__(msg)


class FileNotFoundException(ExptException):
    """
    file not found exception
    """
    def __init__(self, msg):
        super(FileNotFoundException, self).__init__(msg)


class RequestServerException(ExptException):
    """
    request server exception
    """
    def __init__(self, msg):
        super(RequestServerException, self).__init__(msg)


class InvalidTokenException(ExptException):
    """
    request server exception
    """
    def __init__(self, msg):
        super(InvalidTokenException, self).__init__(msg)


class ExperimentNotInitException(ExptException):
    """
    experiment not init exception
    """
    def __init__(self):
        super(ExperimentNotInitException, self).__init__(
            "Experiment has not been initialized. "
            "You should use expt.init(name='exp_name', token='exp_token) to initialize an experiment."
        )



