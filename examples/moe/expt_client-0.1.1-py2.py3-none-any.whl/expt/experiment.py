#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################

"""
experiment class

Authors: yangjintao
Date:    2020/08/24
"""

from .exceptions import FormatException, FileNotFoundException
from .utils import check_args, check_exp_id
from . import api_client
import six
import json
import numpy as np


class Experiment:
    """
    Experiment
    """
    def __init__(self, name, token, job_id='', pod_id='', hyper_params=''):
        """
        init Experiment
        :param name: experiment name
        :param token: token
        :param job_id: job id, related to application platform, like pdc
        :param pod_id: pod id, related to node id for distributed job
        :param hyper_params: experiment hyper params
        """
        self.name = name
        self.token = token
        self.job_id = job_id
        self.pod_id = pod_id
        self.hyper_params = hyper_params
        self.exp_id = None
        self.exp_no = None

    def _set_exp_id(self, exp_id):
        """
        set exp id
        """
        self.exp_id = exp_id

    def _set_exp_no(self, exp_no):
        """
        set exp no
        """
        self.exp_no = exp_no

    def create(self):
        """
        create experiment
        :return:
        """
        exp_id, exp_no = api_client.init(self.name, self.token, self.job_id, self.pod_id, self.hyper_params)
        if exp_id is not None:
            self._set_exp_id(str(exp_id))
            self._set_exp_no(str(exp_no))

    @check_exp_id
    def finish(self, status):
        """
        finish experiment
        """
        if status not in ['success', 'fail']:
            raise FileNotFoundException("status can only be one of 'success' and 'failed'")
        api_client.finish(self.exp_id, self.token, status)

    @check_exp_id
    @check_args(FormatException, params=dict)
    def set_params(self, params):
        """
        update params
        """
        api_client.update_params(self.exp_id, self.token, params)

    @check_exp_id
    @check_args(FormatException, tag=six.string_types, step=six.integer_types, walltime=six.integer_types)
    def add_scalar(self, tag, value, step, walltime=None):
        """
        add scalar
        """
        value = float(value)
        api_client.post_scalar(self.exp_id, self.token, tag, value, step, walltime)

    @check_exp_id
    @check_args(FormatException, tag=six.string_types, img=np.ndarray,
                step=six.integer_types, walltime=six.integer_types)
    def add_image(self, tag, img, step, walltime=None):
        """
        add image
        """
        image = json.dumps(img.tolist())
        api_client.post_image(self.exp_id, self.token, tag, image, step, walltime)

    @check_exp_id
    @check_args(FormatException, tag=six.string_types, audio_array=(list, np.ndarray), step=six.integer_types,
                sample_rate=six.integer_types, walltime=six.integer_types)
    def add_audio(self, tag, audio_array, step, sample_rate=8000, walltime=None):
        """
        add audio
        """
        audio = audio_array.tolist() if isinstance(audio_array, np.ndarray) else audio_array
        audio = json.dumps(audio)
        api_client.post_audio(self.exp_id, self.token, tag, audio, step, sample_rate, walltime)

    @check_exp_id
    @check_args(FileNotFoundException, filepath=six.string_types)
    def add_graph(self, filepath):
        """
        add graph
        :param filepath: local file path of model
        """
        api_client.post_graph(self.exp_id, self.token, filepath)

    @check_exp_id
    @check_args(FormatException, tag=six.string_types, values=(list, np.ndarray), step=six.integer_types,
                walltime=six.integer_types, buckets=six.integer_types)
    def add_histogram(self, tag, values, step, buckets=10, walltime=None):
        """
        add histogram
        """
        values = values.tolist() if isinstance(values, np.ndarray) else values
        values = json.dumps(values)
        api_client.post_histogram(self.exp_id, self.token, tag, values, step, buckets, walltime)

    @check_exp_id
    @check_args(FormatException, tag=six.string_types, labels=(list, np.ndarray), predictions=(list, np.ndarray),
                step=six.integer_types, num_thresholds=six.integer_types, walltime=six.integer_types)
    def add_pr_curve(self, tag, labels, predictions, step, num_thresholds=10, weights=None, walltime=None):
        """
        add pr curve
        """
        weights = 1.0 if weights is None else float(weights)
        labels = labels.tolist() if isinstance(labels, np.ndarray) else labels
        labels = json.dumps(labels)
        predictions = predictions.tolist() if isinstance(predictions, np.ndarray) else predictions
        predictions = json.dumps(predictions)
        api_client.post_pr_curve(self.exp_id, self.token, tag, labels, predictions, step,
                                 num_thresholds, weights, walltime)

    @check_exp_id
    @check_args(FormatException, tag=six.string_types, labels=(list, np.ndarray), hot_vectors=(list, np.ndarray),
                walltime=six.integer_types)
    def add_embeddings(self, tag, labels, hot_vectors, walltime=None):
        """
        add embeddings
        """
        labels = labels.tolist() if isinstance(labels, np.ndarray) else labels
        labels = json.dumps(labels)
        hot_vectors = hot_vectors.tolist() if isinstance(hot_vectors, np.ndarray) else hot_vectors
        hot_vectors = json.dumps(hot_vectors)
        api_client.post_high_dimensional(self.exp_id, self.token, tag, labels, hot_vectors, walltime)











