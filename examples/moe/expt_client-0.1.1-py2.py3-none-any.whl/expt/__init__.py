#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################

"""
init

Authors: yangjintao
Date:    2020/08/24
"""

import os
import time
from .exceptions import NoExpTokenException
from .experiment import Experiment
from .utils import check_init
from . import version

__version = version.version

global cur_experiment


def init(token=None, name=''):
    """
    initialize an experiment
    :param name: exp name
    :param token: token to request server
    :return: expNo
    """
    # If there is SYS_EXP_TOKEN in environment variables, use it to replace what the user fills in,
    # to ensure that experiments run by a certain user always uses his or her own account,
    # especially when submit a shared job.
    sys_token = os.getenv("SYS_EXP_TOKEN")
    if sys_token is not None:
        token = sys_token
    assert token is not None and token != '', NoExpTokenException()

    pod_id = '' if os.getenv('PADDLE_TRAINER_ID') is None else os.getenv('PADDLE_TRAINER_ID')
    job_id = '' if os.getenv('SYS_JOB_ID') is None else os.getenv('SYS_JOB_ID')
    hyper_params = '' if os.getenv('SYS_HYPER_PARAMS') is None else os.getenv('SYS_HYPER_PARAMS')

    global cur_experiment
    cur_experiment = Experiment(name, token, job_id, pod_id, hyper_params)
    cur_experiment.create()
    return cur_experiment.exp_no


@check_init
def add_scalar(tag, value, step, walltime=None):
    """
    add scalar
    refer to https://github.com/PaddlePaddle/VisualDL/blob/develop/docs/components/README.md#Scalar--%E6%A0%87%E9%87%8F%E7%BB%84%E4%BB%B6
    """
    walltime = int(round(time.time())) if walltime is None else walltime
    cur_experiment.add_scalar(tag, value, step, walltime)


@check_init
def add_image(tag, img, step, walltime=None):
    """
    add image
    refer to https://github.com/PaddlePaddle/VisualDL/blob/develop/docs/components/README.md#Image--%E5%9B%BE%E7%89%87%E5%8F%AF%E8%A7%86%E5%8C%96%E7%BB%84%E4%BB%B6
    """
    walltime = int(round(time.time())) if walltime is None else walltime
    cur_experiment.add_image(tag, img, step, walltime)


@check_init
def add_audio(tag, audio_array, step, sample_rate=8000, walltime=None):
    """
    add audio
    refer to https://github.com/PaddlePaddle/VisualDL/blob/develop/docs/components/README.md#Audio--%E9%9F%B3%E9%A2%91%E6%92%AD%E6%94%BE%E7%BB%84%E4%BB%B6
    """
    walltime = int(round(time.time())) if walltime is None else walltime
    cur_experiment.add_audio(tag, audio_array, step, sample_rate=sample_rate, walltime=walltime)


@check_init
def add_graph(filepath):
    """
    add graph
    """
    cur_experiment.add_graph(filepath)


@check_init
def add_histogram(tag, values, step, buckets=10, walltime=None):
    """
    add histogram
    refer to https://github.com/PaddlePaddle/VisualDL/blob/develop/docs/components/README.md#Histogram--%E7%9B%B4%E6%96%B9%E5%9B%BE%E7%BB%84%E4%BB%B6
    """
    walltime = int(round(time.time())) if walltime is None else walltime
    cur_experiment.add_histogram(tag, values, step, walltime=walltime, buckets=buckets)


@check_init
def add_pr_curve(tag, labels, predictions, step, num_thresholds=10, weights=None, walltime=None):
    """
    add pr curve
    refer to https://github.com/PaddlePaddle/VisualDL/blob/develop/docs/components/README.md#PR-Curve--PR%E6%9B%B2%E7%BA%BF%E7%BB%84%E4%BB%B6
    """
    walltime = int(round(time.time())) if walltime is None else walltime
    cur_experiment.add_pr_curve(tag, labels, predictions, step,
                                num_thresholds=num_thresholds, weights=weights, walltime=walltime)


@check_init
def add_embeddings(tag, labels, hot_vectors, walltime=None):
    """
    add embeddings
    refer to https://github.com/PaddlePaddle/VisualDL/blob/develop/docs/components/README.md#High-Dimensional--%E6%95%B0%E6%8D%AE%E9%99%8D%E7%BB%B4%E7%BB%84%E4%BB%B6
    """
    walltime = int(round(time.time())) if walltime is None else walltime
    cur_experiment.add_embeddings(tag, labels, hot_vectors, walltime)


def set_host(host):
    """
    set server host
    :param host: server address, format http://hostname:port
    """
    config_path = "{}/config.py".format(os.path.dirname(os.path.realpath(__file__)))
    with open(config_path, 'r') as f1, open("{}.bak".format(config_path), 'w') as f2:
        for line in f1:
            if line.strip().startswith("TRACE_SERVER_HOST"):
                line = "TRACE_SERVER_HOST = \"{}\"\n".format(host)
            f2.write(line)
    os.remove(config_path)
    os.rename("{}.bak".format(config_path), config_path)


@check_init
def success():
    """
    exp success
    """
    global cur_experiment
    cur_experiment.finish('success')
    del cur_experiment


@check_init
def fail():
    """
    exp fail
    """
    global cur_experiment
    cur_experiment.finish('fail')
    del cur_experiment


@check_init
def set_params(params):
    """
    set hyper params
    :param params: a dict, set params
    """
    cur_experiment.set_params(params)


@check_init
def exp_id():
    """
    return current exp id
    """
    return cur_experiment.exp_id


@check_init
def exp_no():
    """
    return current exp no
    """
    return cur_experiment.exp_no








