#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################

"""
constants
"""

TRACE_SERVER_HOST = "http://paddlecloud.baidu-int.com"

API_VERSION = "v1"

INIT_URI = "{}/exp/init".format(API_VERSION)

PARAM_URI = "{}/exp/updateParams".format(API_VERSION)

SCALAR_URI = "{}/exp/scalar".format(API_VERSION)

IMAGE_URI = "{}/exp/image".format(API_VERSION)

AUDIO_URI = "{}/exp/audio".format(API_VERSION)

HISTOGRAM_URI = "{}/exp/histogram".format(API_VERSION)

PR_CURVE_URI = "{}/exp/prcurve".format(API_VERSION)

HIGH_DIMENSIONAL_URI = "{}/exp/highDimensional".format(API_VERSION)

GRAPH_URI = "{}/exp/graph".format(API_VERSION)

FINISH_URI = "{}/exp/finish".format(API_VERSION)

CONNECTION_TIMEOUT = 10

CONNECTION_RETRY_TIMES = 3






