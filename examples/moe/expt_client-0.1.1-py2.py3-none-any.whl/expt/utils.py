#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################

"""
utils

Authors: yangjintao
Date:    2020/08/25
"""

import six
import os
from .exceptions import FileNotFoundException, ExperimentNotInitException


def check_args(exception, **arg_types):
    """
    check args that users passed to internal
    :param exception: which exception to raise if args-check did not pass
    :param arg_types: a dict, {arg_name: set(int, long)}
    """
    def wrapper(f):
        """
        wrapper
        """
        def check(*args, **kwargs):
            """
            check args
            """
            for i, v in enumerate(args):
                if six.get_function_code(f).co_varnames[i] in arg_types and \
                        not isinstance(v, arg_types[six.get_function_code(f).co_varnames[i]]):
                    raise exception("type of '{}(={})' must be {}".format(
                        six.get_function_code(f).co_varnames[i],
                        v,
                        arg_types[six.get_function_code(f).co_varnames[i]]))

                if six.get_function_code(f).co_varnames[i] == 'tag' and '%' in v:
                    raise exception("'%' can't appear in tag!")
                if six.get_function_code(f).co_varnames[i] == 'filepath' \
                        and not os.path.isfile(os.path.abspath(v)):
                    raise FileNotFoundException(
                        "model file {} does not exist, please check.".format(os.path.abspath(v)))

            for k, v in kwargs.items():
                if k in arg_types and not isinstance(v, arg_types[k]):
                    raise exception("type of '{}(={})' must be {}".format(
                        k, v, arg_types[k]))
                if k == 'tag' and '%' in v:
                    raise exception("'%' can't appear in tag!")
                if k == 'filepath' and not os.path.isfile(os.path.abspath(v)):
                    raise FileNotFoundException(
                        "model file {} does not exist, please check.".format(os.path.abspath(v)))
            return f(*args, **kwargs)
        return check
    return wrapper


def check_init(f):
    """
    check if the experiment has been initialized
    """
    def check(*args, **kwargs):
        """
        check
        """
        try:
            return f(*args, **kwargs)
        except NameError:
            raise ExperimentNotInitException()
    return check


def check_exp_id(f):
    """
    check if the experiment has gotten an expId
    """
    def check(*args, **kwargs):
        """
        check
        """
        if args[0].exp_id is not None:
            return f(*args, **kwargs)
    return check




