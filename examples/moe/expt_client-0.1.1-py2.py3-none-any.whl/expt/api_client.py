#!/usr/bin/env python
# -*- coding: UTF-8 -*-
################################################################################
#
# Copyright (c) 2020 Baidu.com, Inc. All Rights Reserved
#
################################################################################

"""
api client to request server

Authors: yangjintao
Date:    2020/08/24
"""

import requests
from . import config
import json
import json.decoder
from .exceptions import RequestServerException, InvalidTokenException
import six
import time
import traceback

if six.PY3:
    from imp import reload


def request_server(url, json_data=None, data=None, files=None):
    """

    :param url: http url
    :param json_data: data in json format
    :param data: form data
    :param files: files dict
    :return:
    """
    r = None
    # 网络问题/连接超时情况下的重试次数
    retry_times = config.CONNECTION_RETRY_TIMES
    retry = 0

    while retry < retry_times:
        try:
            if json_data is not None:
                r = requests.post(url, json=json_data, timeout=config.CONNECTION_TIMEOUT)
            elif files is not None:
                r = requests.post(url, data=data, files=files, timeout=config.CONNECTION_TIMEOUT)

            if six.PY2:
                try:
                    result = json.loads(str(r.text))
                except ValueError:
                    raise RequestServerException('Decode return json failed, request url is: {}, '
                                                 'response status code is: {}'.format(r.url, r.status_code))
            else:
                try:
                    result = json.loads(str(r.text))
                except json.decoder.JSONDecodeError:
                    raise RequestServerException('Decode return json failed, request url is: {}, '
                                                 'response status code is is: {}'.format(r.url, r.status_code))
            # invalid token
            if result['code'] == 1031:
                msg = '{}\nRequest id is: {}'.format(result['message'], result['requestId'])
                raise InvalidTokenException(msg)
            # other error
            elif result['code'] != 0:
                msg = result['message']
                if result['requestId'] != '':
                    msg += '\nRequest id is: {}'.format(result['requestId'])
                raise RequestServerException(msg)
            return result['data']
        except InvalidTokenException:
            raise
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
            retry += 1
            if retry >= retry_times:
                print('{} - ERROR: Error occurred when expt-client connects server: {}. '
                      'Request url: {}\nTraceback:\n{}'.format(time.strftime('%Y-%m-%d %H:%M:%S'), str(e), url,
                                                               ''.join(traceback.format_stack())))
                return
        except RequestServerException as e:
            print('{} - ERROR: Expt-client server returns error: {}. Request url: {}\nTraceback:\n{}'.format(
                time.strftime('%Y-%m-%d %H:%M:%S'), str(e), url,
                ''.join(traceback.format_stack())))
            return
        except Exception as e:
            print('{} -ERROR: Expt-client throws an error: {}. Request url: {}\n{}'.format(
                time.strftime('%Y-%m-%d %H:%M:%S'), str(e), url, traceback.format_exc()))
            return


def init(exp_name, exp_token, job_id='', pod_id='', hyper_params=''):
    """
    init an experiment
    :return: exp id
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.INIT_URI)
    data = {
        'jobId': job_id,
        'podId': pod_id,
        'expName': exp_name,
        'token': exp_token,
        'hyperParams': hyper_params
    }
    exp_info = request_server(url, json_data=data)
    if exp_info is not None:
        return exp_info['expId'], exp_info['expNo']
    else:
        return None, None


def update_params(exp_id, token, params):
    """
    update params
    :return:
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.PARAM_URI)
    data = {
        'expId': exp_id,
        'token': token,
        'params': json.dumps(params)
    }
    request_server(url, json_data=data)


def finish(exp_id, token, status):
    """
    exp finish
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.FINISH_URI)
    data = {
        'expId': exp_id,
        'token': token,
        'status': status
    }
    request_server(url, json_data=data)


def post_scalar(exp_id, token, tag, value, step, walltime):
    """
    post scalar data
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.SCALAR_URI)
    data = {
        'expId': exp_id,
        'token': token,
        'tag': tag,
        'value': value,
        'step': step,
        'walltime': walltime
    }
    request_server(url, json_data=data)


def post_image(exp_id, token, tag, img, step, walltime):
    """
    post image
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.IMAGE_URI)
    data = {
        'expId': exp_id,
        'token': token,
        'tag': tag,
        'img': img,
        'step': step,
        'walltime': walltime
    }
    request_server(url, json_data=data)


def post_audio(exp_id, token, tag, audio, step, sample_rate, walltime):
    """
    post audio
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.AUDIO_URI)
    data = {
        'expId': exp_id,
        'token': token,
        'tag': tag,
        'step': step,
        'audio': audio,
        'sampleRate': sample_rate,
        'walltime': walltime
    }
    request_server(url, json_data=data)


def post_histogram(exp_id, token, tag, values, step, buckets, walltime):
    """
    post histogram
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.HISTOGRAM_URI)
    data = {
        'expId': exp_id,
        'token': token,
        'tag': tag,
        'hist_values': values,
        'step': step,
        'walltime': walltime,
        'buckets': buckets
    }
    request_server(url, json_data=data)


def post_pr_curve(exp_id, token, tag, labels, predictions, step, thresholds, weights, walltime):
    """
    post pr curve
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.PR_CURVE_URI)
    data = {
        'expId': exp_id,
        'token': token,
        'tag': tag,
        'labels': labels,
        'predictions': predictions,
        'step': step,
        'thresholds': thresholds,
        'weights': weights,
        'walltime': walltime
    }
    request_server(url, json_data=data)


def post_high_dimensional(exp_id, token, tag, labels, vectors, walltime):
    """
    post high dimensional
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.HIGH_DIMENSIONAL_URI)
    data = {
        'expId': exp_id,
        'token': token,
        'tag': tag,
        'labels': labels,
        'vectors': vectors,
        'walltime': walltime
    }
    request_server(url, json_data=data)


def post_graph(exp_id, token, model_path):
    """
    post graph
    """
    reload(config)
    url = "{}/{}".format(config.TRACE_SERVER_HOST, config.GRAPH_URI)
    data = {
        'expId': exp_id,
        'token': token
    }
    files = {'model': open(model_path, 'rb')}
    request_server(url, data=data, files=files)






